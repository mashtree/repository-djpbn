<ul>
	<a href="{{ URL::to('admin/katalog') }}"><li>katalog</li></a>
	<a href="{{ URL::to('admin/aAuthor')}}"><li>author</li></a>
	<li>penerbit</li>
	<li>tags</li>
</ul>