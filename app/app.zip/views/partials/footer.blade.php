	<footer class="footer" align="center">
        <p class="text-muted credit">
            &copy; Dapur Teknologi Persada.
        </p>
    </footer>