<div class="units-row">
<div class="large-6 columns toolbar-search">
<ul>
<li>
	<a href="{{URL::to('/')}}">D R I P<!--<img src="http://localhost/repository-djpbn-master/public/image/google-logo.png">--></a>
</li>
<li>
	<input type="text" size="50%" name="search" id="search" placeholder="type keyword here" >
	</li>
	</ul>
</div>
<div class="large-6 columns toolbar-search">&nbsp;</div>
</div>